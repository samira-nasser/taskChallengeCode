# TaskChallenge

TaskChallenge is a Project BackEnd And FrontEnd  for Displaying the data from database By Angular js and Node js as server side

## Installation

Use the package file to install required files from used technologies versions.

--> Create a package.json file
--> npm install mysql
--> npm install mysql --save
--> sudo npm install -g express-generator



## Running the project

1- Run the back End Project server (Express - Node js)
the command line is openning from projectBackEnd Directory
--> nodemon

2-open the HTML file by browser from projectFrontEnd
  taskDisplay.html
